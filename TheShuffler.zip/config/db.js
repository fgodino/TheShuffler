module.exports = {
	url : 'mongodb://localhost/theshuffler'
}